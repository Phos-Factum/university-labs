#!/bin/bash

# Компиляция программы на языке C
gcc main.c -o main.exe 

# Запуск программы на языке C
./main.exe

# Запуск программы wxmaxima
wxmaxima graphics.wxmx

# Завершение скрипта
exit 0

