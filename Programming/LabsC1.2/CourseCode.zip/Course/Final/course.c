#include "calculations.h"

int main() {
    char again;
    int calculation_done = 0;
    float t[N], Uvx[N], Uvix[N];
    int n = 0;

    do {
        int choice;
        printf("\n\033[34mMenu:\033[0m\n");
        printf("1 - Control calculation for n points\n");
        if (calculation_done) {
            printf("2 - Calculate parameter with precision\n");
            printf("3 - Write data to files\n");
        }
        printf("Enter your choice: ");
        
        // Запрашиваем ввод пользователя
        while (1) {
            if (scanf("%d", &choice) == 1 && choice == 1) {
                break; // Если введено корректное значение для case 1, выходим из цикла
            } else if (calculation_done && (choice == 2 || choice == 3)) {
                break; // Если выполнен case 1 и введено корректное значение для case 2 или 3, выходим из цикла
            } else {
                printf("Invalid choice. Please enter a valid option: ");
                while (getchar() != '\n'); // Очищаем буфер ввода
            }
        }

        printf("\n");

        switch(choice) {
            case 1:
                printf("Enter the number of points: ");
                while (1) {
                    if (scanf("%d", &n) == 1 && n > 0) {
                        control_calculation(n, t, Uvx, Uvix);
                        calculation_done = 1;
                        break; // Если введено корректное значение, выходим из цикла
                    } else {
                        printf("Invalid input. Please enter a positive integer for the number of points: ");
                        while (getchar() != '\n'); // Очищаем буфер ввода
                    }
                }
                break;
            case 2:
                calculate_parameter_with_precision(n);
                break;
            case 3:
                write_data_to_files(n, t, Uvx, Uvix);
                break;
        }

        printf("\n\033[1;33mRepeat program? \033[0m(Y/y - yes | N/n - no): ");
        scanf(" %c", &again); // Запрашиваем ответ пользователя и записываем его в переменную again
        again = tolower(again); // Приводим символ к нижнему регистру

        while (getchar() != '\n'); // Очищаем буфер ввода
    } while (again == 'y');

    return 0;
}
