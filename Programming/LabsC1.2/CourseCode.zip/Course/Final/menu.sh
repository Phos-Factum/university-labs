#!/bin/bash

# Компиляция программы на языке C
gcc test.c -o test.exe 

# Запуск программы на языке C
./test.exe

# Запуск программы wxmaxima
wxmaxima graphics.wxmx

# Завершение скрипта
exit 0

