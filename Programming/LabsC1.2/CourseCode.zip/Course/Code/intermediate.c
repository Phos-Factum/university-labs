#include <stdio.h>
#include <math.h>
#include <ctype.h>

#define N 1000

// Описание функции формирования массива времени form_t
void form_t(int n, float *t, float *dt) {
    float tn = 10, tk = 35;
    *dt = (tk - tn) / (n - 1);
    for (int i = 0; i < n; i++) {
        t[i] = tn + i * (*dt);
    }
}

// Описание функции формирования массива Uvx
void form_Uvx(int n, float *t, float *Uvx) {
    float t1 = 22.5, a = 12, b = 12;
    for (int i = 0; i < n; i++) {
        if (t[i] < t1)
            Uvx[i] = a * (t[i] - 10);
        else
            Uvx[i] = a * (t1 - 10) - b * (t[i] - t1);
    }
}

// Описание функции формирования массива Uvix
void form_Uvix(int n, float *Uvx, float *Uvix) {
    float Uvx1 = 5, Uvx2 = 25, U1 = 20, U2 = 150;
    for (int i = 0; i < n; i++) {
        if (Uvx[i] < Uvx1)
            Uvix[i] = U1;
        else if (Uvx[i] <= Uvx2)
            Uvix[i] = 6.5 * Uvx[i] - 12.5;
        else
            Uvix[i] = U2;
    }
}

// Описание функции вывода данных в виде таблицы form_tabl
void form_tabl(int n, float *t, float *Uvx, float *Uvix) {
    printf("N   t      Uvx   Uvix\n");
    for (int i = 0; i < n; i++) {
        printf("%3d %8.3f %8.3f %8.3f\n", i, t[i], Uvx[i], Uvix[i]);
    }
}

// Описание функции расчета параметра parametr (пример функции, она может быть изменена)
float parametr(int n, float *t, float *Uvx, float *Uvix) {
    // Пример вычисления параметра (может быть изменен в зависимости от задачи)
    return (Uvx[0] + Uvix[n-1]) / 2;
}

// Функция для контрольного расчета для n точек
void control_calculation(int n) {
    float t[N], Uvx[N], Uvix[N], dt;
    form_t(n, t, &dt);
    form_Uvx(n, t, Uvx);
    form_Uvix(n, Uvx, Uvix);
    form_tabl(n, t, Uvx, Uvix);
}

// Функция для расчета параметра с заданной точностью
void calculate_parameter_with_precision() {
    float par = HUGE_VAL; // Очень большое число
    float eps = 0.01; // Заданная погрешность
    float p = 1; // Текущая погрешность
    int n = 11; // Начальное значение точек

    while (p > eps) {
        float t[N], Uvx[N], Uvix[N], dt;
        form_t(n, t, &dt);
        form_Uvx(n, t, Uvx);
        form_Uvix(n, Uvx, Uvix);
        float par1 = parametr(n, t, Uvx, Uvix);
        p = fabs(par - par1) / par1;
        printf("n=%d parametr=%f pogrechnost=%f\n", n, par1, p);
        par = par1;
        n *= 2;
    }
}

int main() {
    char again;

    do {
        int choice;
        printf("Menu:\n");
        printf("1 - Control calculation for n points\n");
        printf("2 - Calculate parameter with precision\n");
        printf("3 - Write data to file\n");
        printf("Enter your choice: ");

        // Запрашиваем ввод пользователя
        while (1) {
            if (scanf("%d", &choice) == 1 && choice >= 1 && choice <= 3) {
                break; // Если введено корректное значение, выходим из цикла
            } else {
                printf("Invalid choice. Please enter a valid option (1, 2 or 3): ");
                while (getchar() != '\n'); // Очищаем буфер ввода
            }
        }

        switch(choice) {
            case 1:
                printf("Enter the number of points: ");
                int n;
                if (scanf("%d", &n) == 1) {
                    control_calculation(n);
                } else {
                    printf("Invalid input.\n");
                    continue; // Переходим к следующей итерации цикла
                }
                break;
            case 2:
                calculate_parameter_with_precision();
                break;
            case 3:
                // Здесь вызывайте функцию для записи данных в файл
                printf("Data written to file.\n");
                break;
        }

        printf("\nRepeat program? (Y/y - yes | N/n - no): ");
        scanf(" %c", &again); // Запрашиваем ответ пользователя и записываем его в переменную again
        again = tolower(again); // Приводим символ к нижнему регистру

        while (getchar() != '\n'); // Очищаем буфер ввода
    } while (again == 'y');

    return 0;
}



