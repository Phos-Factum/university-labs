#include <stdio.h>
#include <math.h>

#define N 1000

int main() {
    float t[N], Uvx[N], Uvix[N]; // Объявление массивов t, Uvx, Uvix
    int n, i;

    printf("Enter the number of points for the control calculation: ");
    scanf("%d", &n); // Ввод необходимого количества точек

    float tn = 10, tk = 35, dt;
    dt = (tk - tn) / (n - 1);

    for (i = 0; i < n; i++) // Формирование массива времени t
        t[i] = tn + i * dt;

    float t1 = 22.5, a = 12, b = 12;

    for (i = 0; i < n; i++) // Формирование массива Uvx
        if (t[i] < t1)
            Uvx[i] = a * (t[i] - tn);
        else
            Uvx[i] = a * (t1 - tn) - b * (t[i] - t1);

    float Uvx1 = 5, Uvx2 = 25, U1 = 20, U2 = 150;

    for (i = 0; i < n; i++) // Формирование массива Uvix
        if (Uvx[i] < Uvx1)
            Uvix[i] = U1;
        else if (Uvx[i] <= Uvx2)
            Uvix[i] = 6.5 * Uvx[i] - 12.5;
        else
            Uvix[i] = U2;

    printf("N   t      Uvx   Uvix\n"); // Вывод заголовков таблицы
    for (i = 0; i < n; i++) // Вывод данных в виде таблицы
        printf("%3d %6.3f %6.3f %6.3f\n", i, t[i], Uvx[i], Uvix[i]);

    return 0;
}
