#include <stdio.h>
#include <math.h>

#define N 1000

// Описание функции формирования массива времени form_t
void form_t(int n, float *t, float *dt) {
    float tn = 10, tk = 35;
    *dt = (tk - tn) / (n - 1);
    for (int i = 0; i < n; i++) {
        t[i] = tn + i * (*dt);
    }
}

// Здесь должны быть описания функций form_Uvx, form_Uvix, form_tabl, parametr

int main() {
    float t[N], Uvx[N], Uvix[N], dt;
    int n;

    printf("Enter n: ");
    scanf("%d", &n);

    form_t(n, t, &dt); // Вызов функции form_t со списком фактических параметров
    // Вызов функции form_Uvx
    // Вызов функции form_Uvix
    // Вызов функции form_tabl
    // Вывод результата работы функции parametr на экран

    return 0;
}
