FILE *f1, *f2, *f3; // Объявление указателя на файловую переменную

f1 = fopen("massiv_t.txt", "w");
f2 = fopen("massiv_Uvx.txt", "w"); // Открытие файлов на запись
f3 = fopen("massiv_Uvix.txt", "w");

if (f1 == NULL || f2 == NULL || f3 == NULL) {
    printf("Error while openning file!\n");
    return 1; // Завершение программы с ошибкой
}

for (int i = 0; i < n; i++) {
    fprintf(f1, "\n%6.3f", t[i]);
    fprintf(f2, "\n%6.3f", Uvx[i]); // Запись данных в файл
    fprintf(f3, "\n%6.3f", Uvix[i]);
}

fclose(f1);
fclose(f2); // Закрытие файлов
fclose(f3);
